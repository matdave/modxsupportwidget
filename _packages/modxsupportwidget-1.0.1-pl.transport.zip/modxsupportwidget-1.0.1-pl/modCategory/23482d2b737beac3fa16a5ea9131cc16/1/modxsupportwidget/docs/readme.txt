MODX Support Widget
==========

MODX Support Widget is an extra for MODX to easily capture support requests in the MODX Dashboard.